import { env } from 'cloudflare:workers'
import type { NormalizedEvent } from './schemas/webhook'
export function database() { if (!env.DB) throw new Error('Visit database is unavailable.'); return env.DB }
export async function listEvents(limit = 200): Promise<NormalizedEvent[]> {
 const rows = await database().prepare('SELECT event FROM visits ORDER BY created_at DESC LIMIT ?').bind(Math.max(1,Math.min(200,limit))).all<{event:string}>()
 return rows.results.map(row => JSON.parse(row.event))
}
export async function addEvent(event: NormalizedEvent) {
 const requestId = typeof event.metadata.request_id === 'string' ? event.metadata.request_id : null
 const results = await database().batch([
  database().prepare('INSERT OR IGNORE INTO visits (id, request_id, created_at, event, revision) VALUES (?, ?, ?, ?, 0)').bind(event.event_id, requestId, Date.now(), JSON.stringify(event)),
  database().prepare('DELETE FROM visits WHERE id NOT IN (SELECT id FROM visits ORDER BY created_at DESC LIMIT 200)'),
 ])
 return results[0].meta.changes > 0
}
