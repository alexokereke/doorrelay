// Hosted access is restricted by Sites to the owner. Never publish this shared
// household version anonymously without adding per-household authorization.
export function checkMutation(request: Request): Response | null {
 const origin=request.headers.get('origin')
 if (origin && origin!==new URL(request.url).origin) return Response.json({error:'Cross-site request rejected.'},{status:403})
 if(request.headers.get('sec-fetch-site')==='cross-site')return Response.json({error:'Cross-site request rejected.'},{status:403})
 return null
}
