import { env } from 'cloudflare:workers'
import { database } from './store'
export type AuthMode = 'access_token'
function vaultKey() { const raw=(env as unknown as Record<string,string>).DOORRELAY_VAULT_KEY; if(!raw || !/^[a-f0-9]{64}$/.test(raw)) throw new Error('Secure token storage is unavailable.');return Uint8Array.from(raw.match(/../g)!,v=>parseInt(v,16)) }
async function key() { return crypto.subtle.importKey('raw',vaultKey(),'AES-GCM',false,['encrypt','decrypt']) }
export async function saveAccessToken(token:string) {
 const iv=crypto.getRandomValues(new Uint8Array(12));const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv},await key(),new TextEncoder().encode(token))
 const value=JSON.stringify({iv:Array.from(iv),ciphertext:Array.from(new Uint8Array(ciphertext))})
 await database().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('ring_access_token',value).run()
}
export async function clearAccessToken() { await database().prepare('DELETE FROM settings WHERE key = ?').bind('ring_access_token').run() }
export async function getAuthMode():Promise<AuthMode|null> {
 const row=await database().prepare('SELECT key FROM settings WHERE key = ?').bind('ring_access_token').first()
 return row?'access_token':null
}
export async function getAccessToken():Promise<string> {
 const row=await database().prepare('SELECT value FROM settings WHERE key = ?').bind('ring_access_token').first<{value:string}>()
 if(!row)throw new Error('Connect Ring using a Playground access token below.')
 const data=JSON.parse(row.value)
 const raw=await crypto.subtle.decrypt({name:'AES-GCM',iv:new Uint8Array(data.iv)},await key(),new Uint8Array(data.ciphertext))
 return new TextDecoder().decode(raw)
}
export async function discoverDevices(token:string) {
 const response=await fetch('https://api.amazonvision.com/v1/devices',{headers:{Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(15000)})
 if(response.status===401)throw new Error('Ring rejected this token (401). Generate a fresh token in Ring Playground, then reconnect below.')
 if(response.status===403)throw new Error('This Ring token does not have access to the selected devices (403).')
 if(!response.ok)throw new Error(`Ring device discovery failed (${response.status}). Please try again.`)
 const data=await response.json() as {data?:Array<{id:string;attributes?:{name?:string;description?:string}}>}
 if(!Array.isArray(data.data))throw new Error('Ring returned an unexpected device response.')
 return data.data.map(device=>({id:device.id,name:device.attributes?.name||device.attributes?.description||'Ring device'}))
}
