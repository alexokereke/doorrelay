import { database } from './store'
export type ResponseStatus = 'answering' | 'help_requested' | 'helper_accepted' | 'needs_attention' | 'resolved'
export type ResponseAction = 'answering' | 'help_requested' | 'helper_accepted' | 'resolved'
export type HouseholdRole = 'resident' | 'helper'
export interface VisitResponse { event_id: string; revision: number; status: ResponseStatus; actor: string; role: HouseholdRole; updated_at: string; help_deadline: string | null }
async function expireRequests() {
 const now = new Date().toISOString()
 await database().prepare(`UPDATE visits SET revision = revision + 1, response = json_set(response, '$.status', 'needs_attention', '$.revision', revision + 1, '$.updated_at', ?) WHERE json_extract(response, '$.status') = 'help_requested' AND json_extract(response, '$.help_deadline') <= ?`).bind(now,now).run()
}
export async function getVisitResponses(): Promise<Record<string,VisitResponse>> {
 await expireRequests()
 const rows = await database().prepare('SELECT id, response FROM visits WHERE response IS NOT NULL').all<{id:string;response:string}>()
 return Object.fromEntries(rows.results.map(row => [row.id, JSON.parse(row.response)]))
}
export function validateTransition(current: VisitResponse | null, action: ResponseAction, role: HouseholdRole): {error:string;status:number} | null {
 if (current?.status === 'resolved') return {error:'This visit is already handled.',status:409}
 if (action === 'help_requested' && role !== 'resident') return {error:'Switch to Resident to request a helper.',status:403}
 if (action === 'helper_accepted' && role !== 'helper') return {error:'Switch to Helper to accept.',status:403}
 if (action === 'helper_accepted' && current?.status !== 'help_requested' && current?.status !== 'needs_attention') return {error:'There is no help request to accept.',status:409}
 if (action === 'answering' && current && current.status !== 'needs_attention') return {error:'Someone is already responding to this visit.',status:409}
 if (action === 'help_requested' && current && ['help_requested','helper_accepted'].includes(current.status)) return {error:'Help is already requested or accepted.',status:409}
 if (action === 'resolved' && !current) return {error:'Choose I’ll answer or Request helper first.',status:409}
 return null
}
export async function setVisitResponse(eventId:string, action:ResponseAction, actor:string, role:HouseholdRole) {
 await expireRequests()
 const row=await database().prepare('SELECT response, revision FROM visits WHERE id = ?').bind(eventId).first<{response:string|null;revision:number}>()
 if (!row) return {error:'That visit is no longer available. Refresh the page.',status:404}
 const current:VisitResponse|null=row.response?JSON.parse(row.response):null
 const invalid=validateTransition(current,action,role);if(invalid)return invalid
 const now=new Date()
 const response:VisitResponse={event_id:eventId,revision:row.revision+1,status:action,actor,role,updated_at:now.toISOString(),help_deadline:action==='help_requested'?new Date(now.getTime()+45000).toISOString():null}
 const result=await database().prepare('UPDATE visits SET response = ?, revision = ? WHERE id = ? AND revision = ?').bind(JSON.stringify(response),response.revision,eventId,row.revision).run()
 if(result.meta.changes!==1)return {error:'Another household member just responded. Review the updated visit and try again.',status:409}
 return {response,status:200}
}
