import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const visits = sqliteTable('visits', {
 id: text('id').primaryKey(), requestId: text('request_id').unique(), createdAt: integer('created_at').notNull(), event: text('event').notNull(), response: text('response'), revision: integer('revision').notNull().default(0),
});
export const settings = sqliteTable('settings', { key: text('key').primaryKey(), value: text('value').notNull() });
