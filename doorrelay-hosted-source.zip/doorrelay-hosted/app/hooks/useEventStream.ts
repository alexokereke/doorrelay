'use client'
import {useEffect,useState} from 'react'
import type {DetectionEvent} from '../components/EventCard'
export function useEventStream({paused=false,maxEvents=200}:{paused?:boolean;maxEvents?:number}={}){
 const [events,setEvents]=useState<DetectionEvent[]>([]);const [connected,setConnected]=useState(false)
 useEffect(()=>{
  let closed=false;let timer:ReturnType<typeof setTimeout>;const controller=new AbortController()
  async function refresh(){try{
   const res=await fetch('/api/ring/events',{cache:'no-store',signal:controller.signal});if(!res.ok)throw new Error('Activity unavailable')
   const data=await res.json() as {events?:DetectionEvent[]};if(!closed){setConnected(true);if(!paused&&Array.isArray(data.events))setEvents(data.events.slice(0,maxEvents))}
  }catch{if(!closed)setConnected(false)}finally{if(!closed)timer=setTimeout(refresh,2000)}}
  void refresh();return()=>{closed=true;clearTimeout(timer);controller.abort()}
 },[paused,maxEvents]);return{events,connected}
}
