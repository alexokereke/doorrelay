'use client'
import {useState} from 'react'
export function RingConnection({onConnected}:{onConnected:()=>void}){
 const [token,setToken]=useState('');const [busy,setBusy]=useState(false);const [message,setMessage]=useState('')
 async function connect(event:React.FormEvent){event.preventDefault();setBusy(true);setMessage('Checking your Ring connection…');try{
  const res=await fetch('/api/ring/connection',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});const data=await res.json() as {error?:string};if(!res.ok)throw new Error(data.error||'Could not connect')
  setToken('');setMessage('Ring connected. Start camera view above.');onConnected()
 }catch(error){setMessage(error instanceof Error?error.message:'Could not connect.')}finally{setBusy(false)}}
 async function disconnect(){setBusy(true);try{const res=await fetch('/api/ring/connection',{method:'DELETE'});if(!res.ok)throw new Error();setMessage('Ring disconnected. Saved access token removed.');onConnected()}catch{setMessage('Could not disconnect. Try again.')}finally{setBusy(false)}}
 return <details className="mt-4 border-t border-slate-700 pt-4"><summary className="font-semibold text-cyan-200">Connect or reconnect Ring</summary>
 <p className="mt-3 text-sm text-slate-300">Open <a href="https://developer.amazon.com/ring/console/playground" target="_blank" rel="noreferrer" className="underline">Ring Playground</a>, generate an access token, and paste it here. It is encrypted on the server and never returned to the browser. Do not paste it into chat.</p>
 <form onSubmit={connect} className="mt-3 space-y-3"><label className="block text-sm">Playground access token<input type="password" autoComplete="off" value={token} onChange={e=>setToken(e.target.value)} maxLength={16000} required className="block mt-2 w-full rounded-lg border border-slate-500 bg-slate-800 p-3" placeholder="Paste your token"/></label>
 <div className="flex flex-wrap gap-3"><button disabled={busy||!token.trim()} className="rounded-lg bg-cyan-300 text-slate-950 font-bold px-4 py-2 disabled:opacity-50">{busy?'Working…':'Connect Ring'}</button><button type="button" disabled={busy} onClick={()=>void disconnect()} className="rounded-lg border border-slate-500 px-4 py-2">Disconnect Ring</button></div></form>
 <p role="status" className="mt-3 text-sm text-cyan-200">{message}</p></details>
}
