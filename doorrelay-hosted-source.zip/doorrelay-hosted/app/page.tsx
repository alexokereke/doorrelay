export { default } from './doorrelay-page'
