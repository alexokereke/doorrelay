import {listEvents} from '@/lib/store'
export const dynamic='force-dynamic'
export async function GET(){const events=await listEvents();return Response.json({events,count:events.length,source:'saved_webhook_store'},{headers:{'Cache-Control':'no-store'}})}
