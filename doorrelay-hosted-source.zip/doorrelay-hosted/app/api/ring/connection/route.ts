import {saveAccessToken,clearAccessToken,discoverDevices} from '@/lib/auth'
import {checkMutation} from '@/lib/request-security'
export async function POST(request:Request){
 const rejected=checkMutation(request);if(rejected)return rejected
 try {
  const body=await request.json() as {token?:unknown}
  if(typeof body.token!=='string'||body.token.trim().length<20||body.token.length>16000)return Response.json({error:'Paste the complete Ring Playground access token.'},{status:400})
  const token=body.token.trim();const devices=await discoverDevices(token)
  if(!devices.length)return Response.json({error:'No devices were returned. Create or select a Playground device first.'},{status:400})
  await saveAccessToken(token)
  return Response.json({connected:true,deviceCount:devices.length},{headers:{'Cache-Control':'no-store'}})
 }catch(error){return Response.json({error:error instanceof Error?error.message:'Could not connect to Ring.'},{status:400})}
}
export async function DELETE(request:Request){const rejected=checkMutation(request);if(rejected)return rejected;await clearAccessToken();return Response.json({connected:false})}
