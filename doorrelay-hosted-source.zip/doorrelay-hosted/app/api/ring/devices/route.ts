import {getAccessToken,discoverDevices} from '@/lib/auth'
export const dynamic='force-dynamic'
export async function GET(){try{return Response.json({devices:await discoverDevices(await getAccessToken())},{headers:{'Cache-Control':'no-store'}})}catch(error){return Response.json({devices:[],error:error instanceof Error?error.message:'Could not discover Ring devices.'},{status:400})}}
