import { getAuthMode } from '@/lib/auth'
import { env } from 'cloudflare:workers'
export const dynamic='force-dynamic'
export async function GET(){return Response.json({mode:await getAuthMode(),testEventsEnabled:(env as unknown as Record<string,string>).DOORRELAY_ENABLE_TEST_EVENTS==='true'},{headers:{'Cache-Control':'no-store'}})}
