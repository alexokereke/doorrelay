import { NextRequest, NextResponse } from 'next/server'
import { checkMutation } from '@/lib/request-security'
import { getAccessToken } from '@/lib/auth'

const API_BASE = 'https://api.amazonvision.com'

export async function POST(request: NextRequest) {
  const rejected = checkMutation(request); if (rejected) return rejected
  try {
    const { sdpOffer, deviceId } = await request.json() as {sdpOffer?:unknown;deviceId?:unknown}

    if (typeof sdpOffer !== 'string' || !sdpOffer || sdpOffer.length > 128_000) {
      return NextResponse.json({ error: 'Missing sdpOffer' }, { status: 400 })
    }

    // Use deviceId from request body, fall back to env var
    const resolvedDeviceId = deviceId || process.env.NEXT_PUBLIC_RING_DEVICE_ID
    if (typeof resolvedDeviceId !== 'string' || !resolvedDeviceId || resolvedDeviceId.length > 1000) {
      return NextResponse.json(
        { error: 'No device ID provided. Pass deviceId in request body or set NEXT_PUBLIC_RING_DEVICE_ID.' },
        { status: 400 }
      )
    }

    const token = await getAccessToken()
    const whepUrl = `${API_BASE}/v1/devices/${encodeURIComponent(resolvedDeviceId)}/media/streaming/whep/sessions`

    const response = await fetch(whepUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/sdp',
      },
      body: sdpOffer,
    })

    if (!response.ok) {
      const error = response.status === 401 ? 'Ring token expired or was rejected. Reconnect Ring with a fresh token.' : 'Please retry the camera connection.'
      return NextResponse.json(
        { error: `WHEP failed: ${response.status} - ${error}` },
        { status: response.status }
      )
    }

    const sdpAnswer = await response.text()
    const location = response.headers.get('Location')
    const sessionUrl = location ? new URL(location, API_BASE).href : null

    return NextResponse.json({ sdpAnswer, sessionUrl })
  } catch (error) {
    console.error('Stream error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Stream failed' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  const rejected = checkMutation(request); if (rejected) return rejected
  try {
    const { sessionUrl } = await request.json() as {sessionUrl?:unknown}
    if (typeof sessionUrl !== 'string' || !sessionUrl) {
      return NextResponse.json({ error: 'Missing sessionUrl' }, { status: 400 })
    }

    let target: URL
    try { target = new URL(sessionUrl) } catch { return NextResponse.json({ error: 'Invalid session URL' }, { status: 400 }) }
    if (target.origin !== API_BASE || !target.pathname.startsWith('/v1/devices/') || !target.pathname.includes('/media/streaming/whep/sessions/')) {
      return NextResponse.json({ error: 'Invalid Ring session URL' }, { status: 400 })
    }
    const token = await getAccessToken()
    await fetch(target, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to close session' }, { status: 500 })
  }
}
