import {env} from 'cloudflare:workers'
import {addEvent} from '@/lib/store'
import {checkMutation} from '@/lib/request-security'
export async function POST(request:Request){
 const rejected=checkMutation(request);if(rejected)return rejected
 if((env as unknown as Record<string,string>).DOORRELAY_ENABLE_TEST_EVENTS!=='true')return Response.json({error:'Demo controls are disabled.'},{status:403})
 const type=new URL(request.url).searchParams.get('type')||'button_press'
 if(!['button_press','motion_detected','package_detected','person_detected'].includes(type))return Response.json({error:'Unknown demo event type.'},{status:400})
 const id=`demo_${crypto.randomUUID()}`
 await addEvent({event_id:id,event_type:type,timestamp:new Date().toISOString(),device_id:'demo-device',confidence:null,bounding_box:null,thumbnail_url:null,metadata:{simulated:true},raw:{source:'DoorRelay demo control',type}})
 return Response.json({status:'simulated',event_id:id,event_type:type})
}
