import {getVisitResponses,setVisitResponse,type ResponseAction,type HouseholdRole} from '@/lib/doorrelay-responses'
import {checkMutation} from '@/lib/request-security'
export const dynamic='force-dynamic'
export async function GET(){return Response.json({responses:await getVisitResponses()},{headers:{'Cache-Control':'no-store'}})}
export async function POST(request:Request){
 const rejected=checkMutation(request);if(rejected)return rejected
 let data: Record<string,unknown>;try{const raw=await request.json();if(!raw||typeof raw!=="object")throw new Error();data=raw as Record<string,unknown>}catch{return Response.json({error:'Expected JSON.'},{status:400})}
 if(!data||typeof data.event_id!=='string'||data.event_id.length>200||typeof data.actor!=='string'||!data.actor.trim()||data.actor.length>32||typeof data.action!=='string'||typeof data.role!=='string'||!['answering','help_requested','helper_accepted','resolved'].includes(data.action)||!['resident','helper'].includes(data.role))return Response.json({error:'Enter a name and choose a valid action and role.'},{status:400})
 const result=await setVisitResponse(data.event_id,data.action as ResponseAction,data.actor.trim(),data.role as HouseholdRole)
 return Response.json('response' in result?{response:result.response}:{error:result.error},{status:result.status})
}
