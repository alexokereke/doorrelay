import type { Metadata } from 'next'
import './globals.css'
export const metadata: Metadata = { title: 'DoorRelay — A shared front door', description: 'Accessible doorbell alerts and a clear resident-to-helper handoff.', icons: { icon: '/favicon.svg' } }
export default function RootLayout({children}: {children: React.ReactNode}) { return <html lang="en"><body>{children}</body></html> }
